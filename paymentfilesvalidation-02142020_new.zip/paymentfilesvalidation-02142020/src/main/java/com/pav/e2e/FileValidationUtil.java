package com.pav.e2e;

import org.testng.annotations.Test;

public class FileValidationUtil {

	@Test
	public void filevalidation() {
	System.out.println("Hurraaaa");
	}
}

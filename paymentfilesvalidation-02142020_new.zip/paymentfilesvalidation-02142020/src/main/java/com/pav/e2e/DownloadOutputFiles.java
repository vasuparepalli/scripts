package com.pav.e2e;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import org.testng.annotations.Test;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class DownloadOutputFiles {
	String baseProjectPath = System.getProperty("user.dir");
	PropertyUtils configObj = new PropertyUtils(baseProjectPath.concat("/src/main/resources/config.property"));
	Session session;
	String destPath = "";

	@Test
	public void downloadFile() {
		try {
			String orgName = System.getProperty("orgName");
			System.out.println("orgName is: " + orgName);
			String planCode = System.getProperty("planCode");
			System.out.println("planCode is: " + planCode);
			String environment = System.getProperty("environment");
			System.out.println("environment is: " + environment);
			String buildNumber = System.getProperty("buildno");
			System.out.println("buildNumber is: " + buildNumber);
			String hostName = configObj.getProperty("hostName");
			String userName = configObj.getProperty("userName");
			String password = configObj.getProperty("password");
			String port = configObj.getProperty("port");
			ChannelSftp connObj = readConnectionDetails(hostName, userName, password, port);
			downloadFile(connObj, orgName, planCode, environment, buildNumber);
			connObj.disconnect();
			session.disconnect();
		} catch (Exception exception) {

		}
	}

	public void downloadFile(ChannelSftp connObj, String orgName, String planCode, String environment,
			String buildNumber) {
		try {
			String paymentTypeConfig = orgName.concat("-").concat(planCode);
			String[] paymentTypes = configObj.getProperty(paymentTypeConfig).split(",");
			System.out.println("paymentTypes" + paymentTypes);
			for (String payment : paymentTypes) {
				destPath = configObj.getProperty("destPath");
				String filePathKey = orgName.concat("-").concat(planCode).concat("-").concat(payment);
				HashMap<String, String> searchValues = getfilePathAndPatternDetails(filePathKey);
				System.out.println("Payment is: " + payment);
				ChannelSftp channelSftp = (ChannelSftp) connObj;
				String remotePath = searchValues.get("remotefilepath").replace("PARAM_ENVNAME", environment)
						.replace("PARAM_PLANCODE", planCode);
				channelSftp.cd(remotePath);
				destPath = destPath.concat("/").concat(buildNumber).concat("/").concat(orgName).concat("/")
						.concat(planCode).concat("/").concat(payment);
				createDirTree(destPath);
				@SuppressWarnings("unchecked")
				Vector<ChannelSftp.LsEntry> directoryEntries = channelSftp.ls("*.xml");
				if (!directoryEntries.isEmpty()) {
					for (ChannelSftp.LsEntry file : directoryEntries) {
						System.out.println(String.format("File - %s", file.getFilename()));
						if (file.getFilename().contains(planCode)
								&& file.getFilename().contains(searchValues.get("key1"))
								&& file.getFilename().contains(searchValues.get("key2"))) {
							System.out.println("File download path - Final :" + remotePath.concat(file.getFilename()));
							channelSftp.get(remotePath.concat("/").concat(file.getFilename()), destPath);
							break;
						}
					}
				} else {
					System.out.println("No files in the directory:" + remotePath);
				}

			}

		} catch (Exception exception) {

		}
	}

	public ChannelSftp readConnectionDetails(String hostName, String userName, String password, String port) {
		ChannelSftp channelSftp = null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(userName, hostName, Integer.parseInt(port));
			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
			session.connect();
			System.out.println("Connected");
			Channel channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp) channel;
		} catch (Exception exception) {

		}
		return channelSftp;
	}

	public boolean createDirTree(String directoryTreeName) {
		try {
			File dir = new File(directoryTreeName);
			if (!dir.exists()) {
				if (dir.mkdirs()) {
					System.out.println("Successfully created");
				} else {
					System.out.println("Not created");
				}

			} else {
				System.out.println("Directory exists, hence not creating");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return false;
	}

	public HashMap<String, String> getfilePathAndPatternDetails(String filePathKey) {
		HashMap<String, String> filePathDetails = new HashMap<String, String>();
		try {
			String fileDetails = configObj.getProperty(filePathKey);
			StringTokenizer fileTokens = new StringTokenizer(fileDetails, ":");
			ArrayList<String> list = new ArrayList<String>();
			list.add("remotefilepath");
			list.add("key1");
			list.add("key2");
			int i = 0;
			while (fileTokens.hasMoreTokens()) {
				filePathDetails.put(list.get(i), fileTokens.nextToken());
				i++;
			}
		} catch (Exception exception) {

		}
		return filePathDetails;

	}

}
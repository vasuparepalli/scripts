package com.pav.paralleltest;

import org.slf4j.Logger;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class util {
	ExtentTest logger;
	Logger LOG;

	public util(ExtentTest logger, Logger LOG) {
		this.logger = logger;
		this.LOG = LOG;
	}

	public void assertValues(GeneralLedgerTransaction objExpected, GeneralLedgerTransaction objActual, String field) {
		SoftAssert assertion = new SoftAssert();
		Object expObj = null;
		Object actObj = null;
		boolean isSuccess = true;
		for (int i = 0; i < objExpected.getDetail().size(); i++) {
			switch (field) {
			case "EntityCode":
				expObj = objExpected.getDetail().get(i).getEntityCode();
				actObj = objActual.getDetail().get(i).getEntityCode();
				break;
			case "AccountNumber":
				expObj = objExpected.getDetail().get(i).getAccountNumber();
				actObj = objActual.getDetail().get(i).getAccountNumber();
				break;
			case "CostCenter":
				expObj = objExpected.getDetail().get(i).getCostCenter();
				actObj = objActual.getDetail().get(i).getCostCenter();
				break;
			case "CostCenterPool":
				expObj = objExpected.getDetail().get(i).getCostCenterPool();
				actObj = objActual.getDetail().get(i).getCostCenterPool();
				break;
			case "Site":
				expObj = objExpected.getDetail().get(i).getSite();
				actObj = objActual.getDetail().get(i).getSite();
				break;
			case "Risk":
				expObj = objExpected.getDetail().get(i).getRisk();
				actObj = objActual.getDetail().get(i).getRisk();
				break;
			case "Product":
				expObj = objExpected.getDetail().get(i).getProduct();
				actObj = objActual.getDetail().get(i).getProduct();
				break;
			case "Market":
				expObj = objExpected.getDetail().get(i).getMarket();
				actObj = objActual.getDetail().get(i).getMarket();
				break;
			case "Operations":
				expObj = objExpected.getDetail().get(i).getOperations();
				actObj = objActual.getDetail().get(i).getOperations();
				break;
			case "CjaCode":
				expObj = objExpected.getDetail().get(i).getCjaCode();
				actObj = objActual.getDetail().get(i).getCjaCode();
				break;
			case "Future":
				expObj = objExpected.getDetail().get(i).getFuture();
				actObj = objActual.getDetail().get(i).getFuture();
				break;
			case "Source":
				expObj = objExpected.getDetail().get(i).getSource();
				actObj = objActual.getDetail().get(i).getSource();
				break;
			case "CycleDate":
				expObj = objExpected.getDetail().get(i).getCycleDate();
				actObj = objActual.getDetail().get(i).getCycleDate();
				break;
			case "GLAmount":
				expObj = objExpected.getDetail().get(i).getGLAmount();
				actObj = objActual.getDetail().get(i).getGLAmount();
				break;
			case "GLDescription":
				expObj = objExpected.getDetail().get(i).getGLDescription();
				actObj = objActual.getDetail().get(i).getGLDescription();
				break;
			}
			if (expObj == null) {
				LOG.info("Expected Data: " + field + " index: " + i + "is null");
				if (actObj == null) {
					LOG.info("Actual Data: " + field + " index: " + i + "is null");
				} else {
					isSuccess = false;
				}
			} else {
				System.out.println("null not occurred");
				if (expObj.toString().equals(actObj.toString())) {
					LOG.info("Success : Expected Data: " + field + " index: " + i + "is: " + expObj.toString());
					LOG.info("Success : Actual Data: " + field + " index: " + i + "is: " + actObj.toString());
				} else {
					LOG.info("Failure : Expected Data: " + field + " index: " + i + "is: " + expObj.toString());
					LOG.info("Failure : Actual Data: " + field + " index: " + i + "is: " + actObj.toString());
					isSuccess = false;
				}
			}
		}
		if (isSuccess) {
			logger.log(Status.PASS, field + "are matching");
		} else {
			logger.log(Status.FAIL, field + "doesn't match");
		}
	}

	public void assertCustomValues(GeneralLedgerTransaction objExpected, GeneralLedgerTransaction objActual,
			String field) {
		boolean isSuccess;
		for (int i = 0; i < objExpected.getDetail().size(); i++) {
			isSuccess = true;
			for (int j = 0; j < objExpected.getDetail().get(i).getCustomElements().getCustomElement().size(); j++) {
				System.out.println(
						objExpected.getDetail().get(i).getCustomElements().getCustomElement().get(j).getValue());
				System.out
						.println(objActual.getDetail().get(i).getCustomElements().getCustomElement().get(j).getValue());
				if (objExpected.getDetail().get(i).getCustomElements().getCustomElement().get(j).getValue().equals(
						objActual.getDetail().get(i).getCustomElements().getCustomElement().get(j).getValue())) {
					LOG.info("Success : Expected Data: " + field + "Customer items index: " + i
							+ "Customer item index: " + j + "is: " + objExpected.getDetail().get(i).getCustomElements()
									.getCustomElement().get(j).getValue().toString());
					LOG.info("Success : Actual Data: " + field + "Customer items index: " + i + "Customer item index: "
							+ j + "is: " + objActual.getDetail().get(i).getCustomElements().getCustomElement().get(j)
									.getValue().toString());
				} else {
					LOG.info("Failure : Expected Data: " + field + "Customer items index: " + i + " Custom item index: "
							+ j + "is: " + objExpected.getDetail().get(i).getCustomElements().getCustomElement().get(j)
									.getValue().toString());
					LOG.info("Failure : Actual Data: " + field + "Customer items index: " + i + " Custom item index: "
							+ j + "is: " + objActual.getDetail().get(i).getCustomElements().getCustomElement().get(j)
									.getValue().toString());
					isSuccess = false;

				}
			}
			if (isSuccess) {
				logger.log(Status.PASS, field + " in position" + i + "are matching");
			} else {
				logger.log(Status.FAIL, field + " in position" + i + "are not maching");
			}
		}

	}
}

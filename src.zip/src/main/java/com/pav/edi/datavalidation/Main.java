package com.pav.edi.datavalidation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pav.paralleltest.PropertyUtils;

//import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class Main {
	String ActFilePath = null;
	String ExpFilePath = null;
	public static String baseProjectPath = System.getProperty("user.dir");
	public static PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/ediconfig.property"));
	
//	final static String DIR_PATH = "H://PavparallelProcessing//";
//	final static String ACTUAL_DIR_PATH = DIR_PATH + "\\actual\\" ;
//	final static String EXPECTED_DIR_PATH = DIR_PATH + "\\Expected\\";
//	final static String RESULTS_DIR_PATH = DIR_PATH + "\\Results\\";
	
	final static String ACTUAL_DIR_PATH = props.getProperty("destPath") ;
	final static String EXPECTED_DIR_PATH = props.getProperty("expPath");
	final static String RESULTS_DIR_PATH = props.getProperty("destPathReports");
	
	final static String DATA835_DIR_NAME = "835DATA";
	final static String CONST_FILENAME = "FileName";
	final static String CONST_SEGMENTNAME = "Segment Name";																	
	final static String CONST_EXPECTED_LINE = "Expected Line";
	final static String CONST_ACTUAL_LINE = "Actual Line";
	final static String CONST_EXPECTED_VAL = "Expected";
	final static String CONST_ACTUAL_VAL = "Actual";

	public static ExtentTest EXTENT_REPORT_LOGGER = null;
	public static ExtentReports EXTENT = null;
	private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

	public static String HTML = "<table><tr><td width=\"10%%\">%s</td><td width=\"10%%\">%s</td>"
			+ "<td width=\"20%%\">%s</td><td width=\"15%%\">%s</td>"
			+ "<td width=\"20%%\">%s</td><td width=\"25%%\">%s</td></tr></table>";

	

	public static String env = null;
	public static String buildnumber = null;
	 public static String orgName = null;
	public static String orgsList = System.getProperty("orgName");// "BCBSNC";;
	public static String bCycleDate = null;
	public static String DBHostname = null;
	public static String DBServName = null;
	public static String DBUsername = null;
	public static String DBPassword = null;
	// To test Locally
	public static void setTestingConfiguration() {
		env = "batche2e";
		buildnumber = "194";
		orgsList = "BCBSNC";
		bCycleDate = "20200519";
	}
	
	static {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(RESULTS_DIR_PATH+"835validationResults.html");
		EXTENT = new ExtentReports();
		EXTENT.attachReporter(reporter);
		EXTENT_REPORT_LOGGER = EXTENT.createTest("835validation");
		setConfigurations();
	}
	
	@BeforeTest
	public static void setConfigurations() {
		
		env =System.getProperty("environment");// "batchsit"; 
		buildnumber =System.getProperty("buildno"); //"174";
				
		bCycleDate =  System.getProperty("BatchCyleDate");////"20200429";

		//setTestingConfiguration();
		System.out.println("\n\nBuild Number is: "+buildnumber);
		System.out.println("Env is: "+env);
		System.out.println("bCycleDate is: "+bCycleDate);

		DBHostname = props.getProperty(env + "_hostname");
		DBServName = props.getProperty(env + "_server");
		DBUsername = props.getProperty(env + "_username");
		DBPassword = props.getProperty(env + "_password");

		System.out.println("orgsList: "+orgsList);
		System.out.println("bCycleDate:[" + bCycleDate + "] " + "DBHostname:[" + DBHostname + "] " + "DBServName:["
				+ DBServName + "] " + "DBUsername:[" + DBUsername + "] " + "DBPassword:[" + DBPassword + "] ");
	}

	// orgList : From Sys variables
	@Test
	public static void iterateOrgs() {
		EXTENT_REPORT_LOGGER.log(Status.INFO, 
				String.format(HTML,"OrgName","PlanCode","FileName", "Segment", "Expected Value", "Actual Value"));
		iteratePlans(FileUtils.explodeString(orgsList));
	}
	
		
	public static void iteratePlans(String[] currOrgs) {
		
		for(String org: currOrgs) {
			String planCodes[] = FileUtils.explodeString(props.getProperty(org));
			for(String planCode: planCodes) {
				// System.out.println(org+"\t"+planCode);
				iterateFiles(org, planCode);
				
			}
		}
		if(null!=EXTENT)
			EXTENT.flush();
	}
	
	public static void iterateFiles(String currOrgName, String currAplancode) {
		//File directory = new File(EXPECTED_DIR_PATH+"\\"+currOrgName+"\\"+currAplancode+"\\"+DATA835_DIR_NAME);
		//System.out.println("directory: "+directory.getName());
		File directory2 = new File(EXPECTED_DIR_PATH+"/"+currOrgName+"/"+currAplancode+"/"+DATA835_DIR_NAME);
		 System.out.println("directory2: "+directory2.getName());
		
		File[] directoryListing = directory2.listFiles();
				
		// Fetch and write all actual files from DB
		for(File expectedFile: directoryListing) {
			LOGGER.info("Expected File -- "+expectedFile.getPath());
			try {
				fetchAndWriteActualFileFromDb(expectedFile, bCycleDate, buildnumber, currOrgName, currAplancode);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		LOGGER.info("Comparison done for all files. Build:"+buildnumber+", Org:"+currOrgName+", Plancode:"+currAplancode);
	}
		
	public static void fetchAndWriteActualFileFromDb(File expectedFile, String currBCycleDate,
			String currBuildnumber, String currOrgName, String currAplancode) throws SQLException{
		
		String expectedFileName = expectedFile.getName().replace(".txt", "");
		String aDBJdbcUrl = "jdbc:oracle:thin:" + DBUsername + "/" + DBPassword + "@" + DBHostname + ":1521/"
				+ DBServName;
//		System.out.println("Jdbc url ::"+aDBJdbcUrl);
		Connection conn;
		try {
			conn = DriverManager.getConnection(aDBJdbcUrl);
			if (conn != null) {
				System.out.println("Connected to DB");
	
				String fileNamebCycleDate = "'%"+expectedFileName+"%"+currBCycleDate+"%"+currAplancode+"%'";//"%1487640207%20200429080%";
				String aQuery = "select A.OUTBD_MSG_PYLD,A.CLM_VCHR_ID from fepl_claim.clm_vchr_outbd_msg a "
						+ "where a. clm_vchr_id LIKE "+fileNamebCycleDate;
				System.out.println("aQuery:" + aQuery);
	
				PreparedStatement pstmt = conn.prepareStatement(aQuery);
				//pstmt.setString(1, fileNamebCycleDate);
				ResultSet rs = pstmt.executeQuery();
				
				while(rs.next()){
					System.out.println("CLM_VCHR_ID:: "+rs.getString(2));
					//InputStream in = rs.getClob(1).getAsciiStream();
					//StringWriter w = new StringWriter();
					try {
						//IOUtils.copy(in, w);
						//writeEDICodeToFile(w.toString(), currBuildnumber, currOrgName, currAplancode);
						// System.out.println(clobAsString);
						
						// File write
						//String targetDir = ACTUAL_DIR_PATH+currBuildnumber+"\\"+currOrgName+"\\"+currAplancode+"\\"+DATA835_DIR_NAME+"\\";
						//System.out.println("targetDir-- "+targetDir);
						String targetDir2 = ACTUAL_DIR_PATH+currBuildnumber+"/"+currOrgName+"/"+currAplancode+"/"+DATA835_DIR_NAME+"/";
						System.out.println("targetDir2-- "+targetDir2);
						
						String actualFileFullName = expectedFileName+".txt";
						System.out.println("Actual file:: "+actualFileFullName);
						FileUtils.writeEDICodeToFile(actualFileFullName, rs.getClob(1).getAsciiStream(), targetDir2);
						
						// File Comparison
						File actualFile = new File(targetDir2+actualFileFullName);
						EDI835Compare.executeFilesComparison(currOrgName, currAplancode,
								expectedFile, actualFile, EXTENT_REPORT_LOGGER);

					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}

	}

	@AfterTest
	public void endReport() {
		// extent.endTest(logger);
		EXTENT.flush();
		// extent.close();
	}

}

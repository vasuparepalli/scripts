package testProj.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.crypto.dsig.keyinfo.KeyValue;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import testProj.test.Data.GeneralLedgerTransaction;
import testProj.test.Data.HPXInputXML;

public class App 
{
	String baseProjectPath = System.getProperty("user.dir");

	ExtentReports extent;
	ExtentTest logger;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");

	@BeforeTest
	public void setUpReport() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/report.html", true);
		extent.addSystemInfo("Host Name", "Test").addSystemInfo("Environment", "XML Validation")
				.addSystemInfo("User Name", "Test");
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = System.getProperty("user.dir") + "/test-output/" + logfilename;
		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}

	}

	// String org, String plancode, String type, String expFolder, String actFolder

	@Test
	public void xmlTest() throws Exception 
	{//(String org, String plancode, String type, String expFolder, String actFolder) throws Exception {
		PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/config.property"));
		System.out.println("Property is: " + props.getProperty("FinanceCheckRecordArrayElements"));
		Logger LOG = LoggerFactory.getLogger(App.class);
		
		ArrayList<String> orgNames = getOrgNames();
		for(String orgName:orgNames)
		{
			ArrayList<String> planCodes = getPlanCodesForOrg(orgName);
			for(String planCode:planCodes) 
			{
				ArrayList<String> payTypes = getPayTypes(orgName);
				for(String payType:payTypes)
				{
					//String expDirName = "/Users/Shared/paymentfilesvalidation/"+orgName+ "/"+ planCode +"/Expected/"+payType;
					//String actDirName = "/Users/Shared/paymentfilesvalidation/"+orgName+ "/"+ planCode +"/Actual/"+payType;
					String expDirName = "H:\\pavautomation\\paymentfilesvalidation\\"+orgName+ "\\"+ planCode +"\\Expected\\"+payType;
					String actDirName = "H:\\pavautomation\\paymentfilesvalidation\\"+orgName+ "\\"+ planCode +"\\Actual\\"+payType;
					System.out.println(expDirName);
					
					ArrayList<String> expFileNames = getFilesFromDir(expDirName);
					ArrayList<String> actFileNames = getFilesFromDir(actDirName);
		
					if(expFileNames.size()!=1 || actFileNames.size()!=1)
					{
						System.out.println("ERROR !! - Either expected or Actual have either more than 1 or 0 files.");
					}
					else 
					{
						String expectedOnlyfilename = expFileNames.get(0);
						String actualOnlyfilename = actFileNames.get(0);
						String expectedfilename = expDirName+"/"+expectedOnlyfilename;
						String actualfilename = actDirName+"/"+actualOnlyfilename;
						System.out.println("Expected File -- "+expectedfilename);
						System.out.println("Actual File -- "+actualfilename);
						//Convert all values that has to be validated to key value pair for iteration
						HashMap<String, String[]> keyValueForFields = new HashMap<String,String[]>();
						keyValueForFields = getKeyValueForFields();
						
						BufferedReader br;
						br = new BufferedReader(new FileReader(new File(actualfilename)));
						String line;
						StringBuilder sbActual;
						sbActual = new StringBuilder();
						while ((line = br.readLine()) != null) {
							sbActual.append(line.trim());
						}
						br = new BufferedReader(new FileReader(new File(expectedfilename)));
						StringBuilder sbExpected;
						sbExpected = new StringBuilder();
						while ((line = br.readLine()) != null) {
							sbExpected.append(line.trim());
						}
						System.out.println("xml Data:" + sbExpected);
						br.close();
						JAXBContext jaxbContext;
						try 
						{
							jaxbContext = JAXBContext.newInstance(HPXInputXML.class);
							Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
							HPXInputXML objActual;
							objActual = (HPXInputXML) jaxbUnmarshaller.unmarshal(new StringReader(sbActual.toString()));
							HPXInputXML objExpected;
							objExpected = (HPXInputXML) jaxbUnmarshaller
									.unmarshal(new StringReader(sbExpected.toString()));
						//	logger = extent.startTest("XML Validation");
							AssertionUtil utilObj = new AssertionUtil(logger, LOG);
							System.out.println(objExpected);
							for(int expCtr=0;expCtr<objExpected.getMailset().size();expCtr++) 
							{
								String expPayIdNo = objExpected.getMailset().get(expCtr).getFinanceCheckRecordArray().getPayeeIDNumber();
								System.out.println("Payee ID Number Expected:"+expPayIdNo);
								for(int actCtr=0;actCtr<objActual.getMailset().size();actCtr++) 
								{
									String actPayIdNo = objExpected.getMailset().get(actCtr).getFinanceCheckRecordArray().getPayeeIDNumber();
									System.out.println("Payee ID Number Actual:"+actPayIdNo);
									if(actPayIdNo.equalsIgnoreCase(expPayIdNo))
									{
										System.out.println("Match Found. Index is "+actCtr);
										Iterator iterator = keyValueForFields.entrySet().iterator(); 
										while (iterator.hasNext()) 
										{ 
								            Map.Entry mapElement = (Map.Entry)iterator.next(); 
								            String fieldType = (String) mapElement.getKey();	
								            String[] fieldsToValidate = (String[]) mapElement.getValue();
								            System.out.println("Starting Validation for "+fieldType);
								            for(String field:fieldsToValidate)
											{
												utilObj.assertValues(objExpected, objActual, expCtr, actCtr, field);
											}
								        } 
										
										
									}
									else 
									{
										System.out.println("Match Not Found for Payee ID Number "+ expPayIdNo);
									}
									
								}
							}
						} catch (JAXBException e) {
							e.printStackTrace();
						} 
					}
					
				}
				
				
			}
		}
	}
	private ArrayList<String> getFilesFromDir(String expDirName) 
	{
		ArrayList<String> fileNames = new ArrayList<String>();
		File dir = new File(expDirName);
		File[] files = dir.listFiles();
		for (File file : files) 
		{
		    if (file.isFile()) 
		    {
		    	fileNames.add(file.getName());
		    }
		}
		return fileNames;
	}

	private ArrayList<String> getPayTypes(String orgName) 
	{
		ArrayList<String> payTypes = new ArrayList<String>();
		switch(orgName)
		{
			case "carefirst":
				List<String> cfList = Arrays.asList( "CHK", "EFT", "NON");
				payTypes.addAll(cfList);
				break;
			case "bsbsnc":
				List<String> bsbList = Arrays.asList( "CHK", "EFT", "NON","NONSUB","SUBCHK");
				payTypes.addAll(bsbList);
				break;
		}
		return payTypes;
					
	}

	private ArrayList<String> getPlanCodesForOrg(String orgName) 
	{
		ArrayList<String> planCodes = new ArrayList<String>();
		if(orgName.equalsIgnoreCase("carefirst"))
		{
			planCodes.add("080");// "080","580","581"};
			//planCodes.add("580");
			//planCodes.add("581");
		}
		else if(orgName.equalsIgnoreCase("bcbsnc"))
		{
			planCodes.add("810");
		}
		return planCodes;
	}

	private ArrayList<String> getOrgNames() 
	{
		ArrayList<String> orgNames = new ArrayList<String>();
		orgNames.add("carefirst");
		//orgNames.add("bcbsnc");
		return orgNames;
	}
	private HashMap<String, String[]> getKeyValueForFields() 
	{
		HashMap<String,String[]> keyValueForFields = new HashMap<String,String[]>();
		String[] fieldsToValidateForFCRArray = {"PayeeName","CheckAmount","VoucherCode","StateCode","FEPSPLIT1HO","FEPSPLIT2SO","FEPSPLIT3BO","FEPSPLIT4HMO",
				"FEPSPLIT5SS","FEPSPLIT6BF","PayeeAddress1","PayeeAddress2","PayeeAddress3","PayeeCity","PayeeState","PayeeZip","PayeeAlternateID",
				"MBRNumber","PayeeType","PaymentType","TaxId","PlanCode"};
		String[] fieldsToValidateForSPRElements= {"OutputFormat","Application","HPXPrintInd","MedicalOrDental"};
		String[] fieldsToValidateForNOPRD = {"MailingAddFirstName","ChkMailingAddLine1","ChkMailingAddCity","ChkMailingAddState","ChkMailingAddZip","CheckAmountSummary"};
		String[] fieldsToValidateForPaymentElements = {"ProviderNumber","ProviderTaxID","ProviderNPINumber","PayeeNumber"};
		String[] fieldsToValidateForRemarkElements = {"RemarkCode","RemarkDescription","ClaimNumber"};

		keyValueForFields.put("FCRArray", fieldsToValidateForFCRArray);
		keyValueForFields.put("SPREElements", fieldsToValidateForSPRElements);
		keyValueForFields.put("NOPRD", fieldsToValidateForNOPRD);
		keyValueForFields.put("PaymentElements", fieldsToValidateForPaymentElements);
		keyValueForFields.put("RemarkElements", fieldsToValidateForRemarkElements);
		return keyValueForFields;
	}

	@AfterTest
	public void endReport() {
		//extent.endTest(logger);
		//extent.flush();
		//extent.close();
	}
	
}

package testProj.test;

import java.io.Serializable;

import org.slf4j.Logger;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import testProj.test.Data.GeneralLedgerTransaction;
import testProj.test.Data.HPXInputXML;
import testProj.test.Data.RemarkArray;
public class AssertionUtil {
	ExtentTest logger;
	Logger LOG;

	public AssertionUtil(ExtentTest logger, Logger LOG) {
		this.logger = logger;
		this.LOG = LOG;
	}

	public void assertValues(HPXInputXML objExpected, HPXInputXML objActual, int expIndex, int actIndex, String field) 
	{
		boolean isSuccess = true;
		String ActualValue="";
		String expectedValue="";
		switch(field)
		{
			case "PayeeName":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeName());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeName());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "CheckAmount":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getCheckAmount());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getCheckAmount());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "VoucherCode":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getVoucherCode());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getVoucherCode());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "StateCode":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getStateCode());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getStateCode());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT1HO":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT1HO());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT1HO());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT2SO":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT2SO());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT2SO());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT3BO":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT3BO());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT3BO());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT4HMO":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT4HMO());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT4HMO());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT5SS":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT5SS());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT5SS());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "FEPSPLIT6BF":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT6BF());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT6BF());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeAddress1":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress1());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress1());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeAddress2":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress2());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress2());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeAddress3":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress3());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress3());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeCity":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeCity());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeCity());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeState":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeState());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeState());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeZip":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeZip());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeZip());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeAlternateID":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAlternateID());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAlternateID());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "MBRNumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getMBRNumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getMBRNumber());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			//Validations for SPREElements
			case "OutputFormat":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getOutputFormat());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getOutputFormat());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "Application":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getApplication());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getApplication());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "HPXPrintInd":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getHPXPrintInd());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getHPXPrintInd());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "MedicalOrDental":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getMedicalOrDental());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getMedicalOrDental());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			//Validation for NOPRD
			case "MailingAddFirstName":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getMailingAddFirstName());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getMailingAddFirstName());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ChkMailingAddLine1":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddLine1());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddLine1());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ChkMailingAddCity":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddCity());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddCity());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ChkMailingAddState":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddState());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddState());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ChkMailingAddZip":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddZip());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddZip());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "CheckAmountSummary":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getCheckAmountSummary());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getCheckSummaryDetails().getSummaryPageArray().getCheckAmountSummary());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			//Validation of Payment elements
			case "ProviderNumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getPaymentDetails().getProviderNumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getPaymentDetails().getProviderNumber());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ProviderTaxID":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getPaymentDetails().getProviderTaxID());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getPaymentDetails().getProviderTaxID());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "ProviderNPINumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getPaymentDetails().getProviderNPINumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getPaymentDetails().getProviderNPINumber());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
				
			case "PayeeNumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getPaymentDetails().getPayeeNumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getPaymentDetails().getPayeeNumber());
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
				break;
			
		
		  //Validation for remark element 
			/*case "RemarkCode":
				validateRemarks(objExpected,objActual,field, expIndex,actIndex);
				break;
				
		  case "RemarkDescription": 
			  validateRemarks(objExpected,objActual,field,expIndex,actIndex); 
			  break;
		 */
		}
	}
	private boolean validateRemarks(HPXInputXML objExpected, HPXInputXML objActual, String field, int expIndex, int actIndex) 
	{
		String expectedValue="";
		String ActualValue = "";
		boolean isSuccess = true;
		for(int ctr=0;ctr<objExpected.getMailset().get(expIndex).getNOPRemitDetails().getRemarks().getContent().size();ctr++)
		{
			RemarkArray ra= (RemarkArray) objExpected.getMailset().get(expIndex).getNOPRemitDetails().getRemarks().getContent().get(ctr);
			if(field == "RemarkCode")
			{
				expectedValue = String.valueOf(ra.getRemarkCode());
				ActualValue = String.valueOf(ra.getRemarkCode());
			}
			else if(field == "RemarkDescription")
			{
				expectedValue = String.valueOf(ra.getRemarkDescription());
				ActualValue = String.valueOf(ra.getRemarkDescription());
			}
				isSuccess = validateAndPublish(expectedValue,ActualValue,field);
		}
		return isSuccess;
		
	}

	public boolean validateAndPublish(String expectedValue, String ActualValue, String field)
	{
		boolean isSuccess = true;
		if(expectedValue.equalsIgnoreCase(ActualValue))
		{
				LOG.info("Success : Expected Data for " + field + " is: " + expectedValue);
				LOG.info("Success : Actual Data for " + field + " is: " + ActualValue);
			
		} 
		else 
		{
				LOG.info("Failure : Expected Data for " + field + " is: " + expectedValue);
				LOG.info("Failure : Actual Data for " + field + " is: " + ActualValue);
				isSuccess = false;
		}
		return isSuccess;
	}
}

package testProj.test;

public class XMLAssert {

}

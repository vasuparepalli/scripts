package testProj.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import testProj.test.Data.HPXInputXML;
import testProj.test.Data.HPXInputXML.Mailset.NOPRemitDetails.ClaimArray;
import testProj.test.Data.HPXInputXML.Mailset.NOPRemitDetails.ClaimArray.ClaimLineArray;
import testProj.test.Data.HPXInputXML.Mailset.NOPRemitDetails.Remarks;
import testProj.test.Data.HPXInputXML.Mailset.NOPRemitDetails.Remarks.RemarkArray;


public class AssertionUtilCarefirst {
	ExtentTest logger;
	Logger LOG;
	String fileName;
	boolean result;
	public AssertionUtilCarefirst(ExtentTest logger, Logger LOG, String fileName) {
		this.logger = logger;
		this.LOG = LOG;
		this.fileName = fileName;
		
	}

	public boolean assertValues(HPXInputXML objExpected, HPXInputXML objActual, int expIndex,
			int actIndex, String field) {
		String ActualValue = "";
		String expectedValue = "";
		this.result = result;
		String payeeid = "";
		try {

			payeeid = objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeIDNumber();
			
			
			switch (field) {

			case "PayeeName":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeName());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeName());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "CheckAmount":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getCheckAmount());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getCheckAmount());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "VoucherCode":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getVoucherCode());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getVoucherCode());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "StateCode":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getStateCode());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getStateCode());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT1HO":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT1HO());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT1HO());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT2SO":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT2SO());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT2SO());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT3BO":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT3BO());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT3BO());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT4HMO":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT4HMO());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT4HMO());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT5SS":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT5SS());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT5SS());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "FEPSPLIT6BF":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getFEPSPLIT6BF());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getFEPSPLIT6BF());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeAddress1":
				expectedValue = String.valueOf(
						objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress1());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress1());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeAddress2":
				expectedValue = String.valueOf(
						objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress2());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress2());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeAddress3":
				expectedValue = String.valueOf(
						objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAddress3());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAddress3());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeCity":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeCity());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeCity());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeState":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeState());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeState());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeZip":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeZip());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeZip());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeAlternateID":
				expectedValue = String.valueOf(
						objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getPayeeAlternateID());
				ActualValue = String.valueOf(
						objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getPayeeAlternateID());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "MBRNumber":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getFinanceCheckRecordArray().getMBRNumber());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getFinanceCheckRecordArray().getMBRNumber());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			// Validations for SPREElements
			case "OutputFormat":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getOutputFormat());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getOutputFormat());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "Application":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getApplication());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getApplication());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "HPXPrintInd":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getHPXPrintInd());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getHPXPrintInd());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "MedicalOrDental":
				expectedValue = String
						.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getMedicalOrDental());
				ActualValue = String
						.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails().getMedicalOrDental());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			// Validation for NOPRD
			case "MailingAddFirstName":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getMailingAddFirstName());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getMailingAddFirstName());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ChkMailingAddLine1":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddLine1());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddLine1());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ChkMailingAddCity":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddCity());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddCity());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ChkMailingAddState":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddState());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddState());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ChkMailingAddZip":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddZip());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getChkMailingAddZip());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "CheckAmountSummary":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getCheckAmountSummary());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getCheckSummaryDetails().getSummaryPageArray().getCheckAmountSummary());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			// Validation of Payment elements
			case "ProviderNumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderNumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderNumber());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ProviderTaxID":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderTaxID());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderTaxID());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "ProviderNPINumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderNPINumber());
				ActualValue = String.valueOf(objActual.getMailset().get(actIndex).getNOPRemitDetails()
						.getPaymentDetails().getProviderNPINumber());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;

			case "PayeeNumber":
				expectedValue = String.valueOf(objExpected.getMailset().get(expIndex).getNOPRemitDetails()
						.getPaymentDetails().getPayeeNumber());
				ActualValue = String.valueOf(
						objActual.getMailset().get(actIndex).getNOPRemitDetails().getPaymentDetails().getPayeeNumber());
				validateAndPublish(expectedValue, ActualValue, field, payeeid);
				break;
			case "RemarkDescription":
				validateRemarks(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getRemarks().getContent()
						,objActual.getMailset().get(actIndex).getNOPRemitDetails().getRemarks().getContent(),payeeid);
				break;
			case "ClaimNumber":
				validateClaimArray(objExpected.getMailset().get(expIndex).getNOPRemitDetails().getClaimArray(),
						objActual.getMailset().get(actIndex).getNOPRemitDetails().getClaimArray(),payeeid);
				break;

			}

		} catch (Exception e) {
			System.out.println("Exception Occured");
			logger.log(LogStatus.SKIP, "Error while reading one of the tag for " + field + " from XML file for payeeid "+  payeeid );
			result=false;
		}
		return result;
	}

	
	private void validateClaimArray(List<ClaimArray> expClaimArray, List<ClaimArray> actClaimArray, String payeeid) 
	{
		if(actClaimArray.size()<1 || expClaimArray.size()<1)
		{
			LOG.info("Empty claim array");
			logger.log(LogStatus.FAIL, "Expected or Actual Claim array is empty");
			
		}
		
		else if(expClaimArray.size()!=actClaimArray.size())
		{
			LOG.info("Size of claim array not matching. Expected - "+expClaimArray.size()+" Actual -"+actClaimArray.size());
			validateAndPublish(String.valueOf(expClaimArray.size()),String.valueOf(actClaimArray.size())," Claim Array Size ",payeeid);
		}
		else
		{
			for(int clCtr=0;clCtr<expClaimArray.size();clCtr++)
			{
				List<ClaimLineArray> expCla = expClaimArray.get(clCtr).getClaimLineArray();
				List<ClaimLineArray> actCla = actClaimArray.get(clCtr).getClaimLineArray();
				
				for(int claCtr=0;claCtr<expCla.size();claCtr++)
				{
					
					String expClaimNo = expCla.get(claCtr).getClaimNumber();
					String actClaimNo = actCla.get(claCtr).getClaimNumber();
					validateAndPublish(expClaimNo,actClaimNo," Claim Number ","");
				}
			}
		}
	}

	public void validateRemarks(List<Serializable> expContent,List<Serializable> actContent, String PayeeID)
	{
		if(actContent.size()<1)
		{
			LOG.info("Remark Array Received with size zero");
		}
		else if(actContent.size() != expContent.size())
		{
			LOG.info("Size of Remark tag do not match. Expected - "+expContent.size() + " Actual - " + actContent.size());
			validateAndPublish(String.valueOf(expContent.size()), String.valueOf(actContent.size()), "Remark Array Size for PayeeID "+ PayeeID, PayeeID);
		}
		else
		{
			ArrayList<RemarkArray> expRemarks = fetchRemarkArrays(expContent);
			ArrayList<RemarkArray> actRemarks = fetchRemarkArrays(actContent);
			
			for(int ctr=0;ctr<expRemarks.size();ctr++)
			{
				boolean isFound=false;
				String expRemarkCode = expRemarks.get(ctr).getRemarkCode();
				String actRemarkCode = actRemarks.get(ctr).getRemarkCode();
				validateAndPublish(expRemarkCode,actRemarkCode," Remark Code ","");
				
				String expRemarkDesc = expRemarks.get(ctr).getRemarkDescription();
				String actRemarkDesc = actRemarks.get(ctr).getRemarkDescription();
				validateAndPublish(expRemarkDesc,actRemarkDesc," Remark Description ","");
			}
			
		}
	}
	public ArrayList<RemarkArray> fetchRemarkArrays(List<Serializable> Content)
	{
		ArrayList<RemarkArray> remarks = new ArrayList<RemarkArray>();
		for (int i = 0; i < Content.size(); i++) 
		{
            if ( !(Content.get(i) instanceof JAXBElement) ) {
                continue;
            }
            JAXBElement<?> elem = (JAXBElement<?>) Content.get(i);
	            if ( elem.getValue() instanceof RemarkArray ) {
	            	RemarkArray ra = (RemarkArray) elem.getValue();
	            	remarks.add(ra);
	            }
        }
		return remarks;
	}
	public void validateAndPublish(String expectedValue, String ActualValue, String field, String payeeid) {
		if (expectedValue.equalsIgnoreCase(ActualValue)) {
			LOG.info("Success : Expected Data for " + field + " is: " + expectedValue);
			LOG.info("Success : Actual Data for " + field + " is: " + ActualValue);
			

		} else {
			LOG.info("Failure : Expected Data for " + field + " is: " + expectedValue);
			LOG.info("Failure : Actual Data for " + field + " is: " + ActualValue);
			result=false;
			logger.log(LogStatus.FAIL, "Payee ID - " + payeeid + " \nField " + field + " \nExpected Value - "
					+ expectedValue + ". \nActual Value - " + ActualValue);
		}
	}
}
package testProj.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import testProj.test.Data.FinancialTransaction;
import testProj.test.Data.HPXInputXML;


public class App {
	String baseProjectPath = System.getProperty("user.dir");

	ExtentReports extent;
	ExtentTest logger;
	// ExtentHtmlReporter htmlReporter;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");
	Logger LOG = LoggerFactory.getLogger(App.class);
	FileUtils fUtils = new FileUtils();
	InitializationUtil inUtil= new InitializationUtil();
	@BeforeTest
	public void setUpReport() {
		// htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +
		// "/test-output/report.html");
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/report.html");
		// extent.setSystemInfo("Host Name", "Test");
		// extent.setSystemInfo("Environment", "XML Validation");
		// extent.setSystemInfo("User Name", "Test");
		extent.addSystemInfo("Host Name", "Test").addSystemInfo("Environment", "XML Validation")
				.addSystemInfo("User Name", "Test");
		extent.loadConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
		// htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir") +
		// "/extent-config.xml"));
		// extent.attachReporter(htmlReporter);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = System.getProperty("user.dir") + "/test-output/" + logfilename;
		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}
		// logger=extent.createTest("dsdsds");
		// logger = extent.createTest("sadasdasda");
	}

	// String org, String plancode, String type, String expFolder, String actFolder
	@Test
	public void xmlTest() throws Exception { // (String org, String plancode, String type, String expFolder, String
												// actFolder) throws Exception {
		PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/config.property"));
		System.out.println("Property is: " + props.getProperty("FinanceCheckRecordArrayElements"));
		ArrayList<String> orgNames = inUtil.getOrgNames();
		for (String orgName : orgNames) {
			ArrayList<String> planCodes = inUtil.getPlanCodesForOrg(orgName);
			for (String planCode : planCodes) {
				ArrayList<String> payTypes = inUtil.getPayTypes(orgName);
				for (String payType : payTypes) 
				{
					String expDirName = "/Users/Shared/paymentfilesvalidation/" + orgName + "/" + planCode + "/Expected/" + payType;
					String actDirName = "/Users/Shared/paymentfilesvalidation/" + orgName + "/" + planCode + "/Actual/" + payType;
					System.out.println(expDirName);

					ArrayList<String> expFileNames = fUtils.getFilesFromDir(expDirName);
					ArrayList<String> actFileNames = fUtils.getFilesFromDir(actDirName);

					if (expFileNames.size() != 1 || actFileNames.size() != 1) {
						logger = extent.startTest(expDirName);
						System.out.println("ERROR !! - Either expected or Actual have either more than 1 or 0 files.");
						logger.log(LogStatus.FAIL, "Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("DDDDDD "+logger.getRunStatus());

					} 
					else 
					{
						try
						{
							String expectedOnlyfilename = expFileNames.get(0);
							String actualOnlyfilename = actFileNames.get(0);
							String expectedfilename = expDirName + "/" + expectedOnlyfilename;
							String actualfilename = actDirName + "/" + actualOnlyfilename;
							LOG.info("Expected File -- " + expectedfilename);
							LOG.info("Actual File -- " + actualfilename);
							// Convert all values that has to be validated to key value pair for iteration
							
	
							StringBuilder sbExpected = fUtils.readFileToString(expectedfilename);
							StringBuilder sbActual = fUtils.readFileToString(actualfilename);
	
							switch(orgName)
							{
								case "carefirst":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateCarefirst(expectedOnlyfilename,sbExpected,sbActual,payType);
									break;
								case "bcbsnc":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual,payType);
									break;
								case "premera":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual,payType);
									break;
								case "wellmark":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual,payType);
									break;
							}									
						}
						catch(Exception e)
						{
							logger.log(LogStatus.ERROR, "Error parsing xml");
						}
					}
					
					if(logger.getRunStatus().toString().equalsIgnoreCase("skip") || 
							logger.getRunStatus().toString().equalsIgnoreCase("fail") ||
							logger.getRunStatus().toString().equalsIgnoreCase("error"))
					{
						
					}
					else 
					{
						logger.log(LogStatus.PASS, "All elements passed");
					}
				}

			}
		}
	}

	private void validateNonCarefirst(String expectedOnlyfilename, StringBuilder sbExpected, StringBuilder sbActual, String payType) 
	{
		try 
		{

			FinancialTransaction objExpected = fUtils.unmarshallFTXML(sbExpected);
			FinancialTransaction objActual = fUtils.unmarshallFTXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = inUtil.getKeyValueForFields( payType);
			if (objActual.getDetail().size() != objExpected.getDetail().size()) {
				logger.log(LogStatus.FAIL,
						"Count of Detail do not match. Expected -" + objExpected.getDetail().size()
								+ " Actual - " + objActual.getDetail().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getDetail().size()
						+ " Actual - " + objActual.getDetail().size());
				
			}
			for (int expCtr = 0; expCtr < objExpected.getDetail().size(); expCtr++) {
				String expPayIdNo = objExpected.getDetail().get(expCtr).getFinanceCheckRecordArray()
						.getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(LogStatus.SKIP, "Empty Payee No detected");
					
					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;

					for (int actCtr = 0; actCtr < objActual.getDetail().size(); actCtr++) {
						String actPayIdNo = objActual.getDetail().get(actCtr)
								.getFinanceCheckRecordArray().getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println(
									"Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);
								for (String field : fieldsToValidate) 
								{
									AssertionUtilOthers utilObj = new AssertionUtilOthers(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr,
											actCtr, field);
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(LogStatus.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}
					
					
				}

			}

			LOG.info("DDDDDD "+logger.getRunStatus());
			
		} catch (JAXBException e) {
			logger.log(LogStatus.ERROR, "Error Parsing file");
			e.printStackTrace();
		}
		
	}

	private void validateCarefirst(String expectedOnlyfilename,StringBuilder sbExpected,StringBuilder sbActual, String payType) 
	{
		try {

			HPXInputXML objExpected = fUtils.unmarshallXML(sbExpected);
			HPXInputXML objActual = fUtils.unmarshallXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = getKeyValueForFields(payType);
			
			if (objActual.getMailset().size() != objExpected.getMailset().size()) {
				logger.log(LogStatus.FAIL,
						"Count of mailset do not match. Expected -" + objExpected.getMailset().size()
								+ " Actual - " + objActual.getMailset().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getMailset().size()
						+ " Actual - " + objActual.getMailset().size());
				
			}
			for (int expCtr = 0; expCtr < objExpected.getMailset().size(); expCtr++) {
				String expPayIdNo = objExpected.getMailset().get(expCtr).getFinanceCheckRecordArray()
						.getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(LogStatus.SKIP, "Empty Payee No detected");
					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;

					for (int actCtr = 0; actCtr < objActual.getMailset().size(); actCtr++) {
						String actPayIdNo = objActual.getMailset().get(actCtr)
								.getFinanceCheckRecordArray().getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println(
									"Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);
								for (String field : fieldsToValidate) {
									AssertionUtilCarefirst utilObj = new AssertionUtilCarefirst(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr,
											actCtr, field);
									// utilObj.assertValues(objExpected, objActual, expCtr, actCtr,
									// field).putAll(results);;
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(LogStatus.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}
					

				}

			}

		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
	}

	


	private HashMap<String, String[]> getKeyValueForFields(String payType) {
		// TODO Auto-generated method stub
		return null;
	}

	@AfterTest
	public void endReport() {
		// extent.endTest(logger);
		extent.flush();
		// extent.close();
	}

}
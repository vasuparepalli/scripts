package testProj.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import testProj.test.Data.GeneralLedgerTransaction;

public class App {

	ExtentReports extent;
	ExtentTest logger;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");

	@BeforeTest
	public void setUpReport() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/report.html", true);
		extent.addSystemInfo("Host Name", "Test").addSystemInfo("Environment", "XML Validation")
				.addSystemInfo("User Name", "Test");
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = System.getProperty("user.dir") + "/test-output/" + logfilename;
		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}

	}

	@AfterTest
	public void endReport() {
		extent.endTest(logger);
		extent.flush();
		extent.close();
	}

	// PlanOrg='CAREFIRST'
	//PlanCode= '080' ,'580','581'
	//080
	//Expected File Path= E:\Automation\pav\PavRegression\GLoutput\Expected	
	//Actual File Path=E:\Automation\pav\PavRegression\GLoutput\Actual
	
	//PlanOrg='BCBSNC
	//PlanCode=810
	//FileName= FEP_Carefirst_BlueNC_GL_810_20191114
	//Expected File Path= E:\Automation\pavnc\PavRegression\GLoutput\Expected	
	//Actual File Path=E:\Automation\pavnc\PavRegression\GLoutput\Actual

	@Test
	public void xmlTest() throws IOException {
		Logger LOG = LoggerFactory.getLogger(App.class);
		String actualfilename = System.getProperty("user.dir") + "/src/main/resources/FEP_BlueNC_GL_810_Actual.xml";
		String expectedfilename = System.getProperty("user.dir") + "/src/main/resources/FEP_BlueNC_GL_810_Expected.xml";
		BufferedReader br;
		br = new BufferedReader(new FileReader(new File(actualfilename)));
		String line;
		StringBuilder sbActual;
		sbActual = new StringBuilder();
		while ((line = br.readLine()) != null) {
			sbActual.append(line.trim());
		}
		br = new BufferedReader(new FileReader(new File(expectedfilename)));
		StringBuilder sbExpected;
		sbExpected = new StringBuilder();
		while ((line = br.readLine()) != null) {
			sbExpected.append(line.trim());
		}
		System.out.println("xml Data:" + sbExpected);
		br.close();
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(GeneralLedgerTransaction.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			GeneralLedgerTransaction objActual;
			objActual = (GeneralLedgerTransaction) jaxbUnmarshaller.unmarshal(new StringReader(sbActual.toString()));
			GeneralLedgerTransaction objExpected;
			objExpected = (GeneralLedgerTransaction) jaxbUnmarshaller
					.unmarshal(new StringReader(sbExpected.toString()));
			logger = extent.startTest("XML Validation");
			util utilObj = new util(logger, LOG);
			String[] elementsToValidate = new String[] { "EntityCode", "CostCenter", "CostCenterPool", "Site", "Risk",
					"Product", "Market", "Operations", "Project", "CjaCode", "Future", "CjaCode", "Future", "Source",
					"CycleDate", "GLAmount", "GLDescription" };
			for (String element : elementsToValidate) {
				utilObj.assertValues(objExpected, objActual, element);
			}
			utilObj.assertCustomValues(objExpected, objActual, "CustomElements");
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
}

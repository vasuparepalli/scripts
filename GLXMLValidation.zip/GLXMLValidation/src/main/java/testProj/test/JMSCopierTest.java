package testProj.test;


import static org.junit.Assert.*;

import org.junit.Test;

public class JMSCopierTest
{

@Test
public void testSendLocalFilesToJMSQueue()
{
JMSCopier copier = new JMSCopier();

String filePath = "C:/FileDrop/SIT-UC04";
String queueName = "jms/FepocReplyToQueue";

try
{
copier.sendFileToJMS(filePath, queueName);
}
catch (Exception e)
{
fail(e.getMessage());
}
}

}

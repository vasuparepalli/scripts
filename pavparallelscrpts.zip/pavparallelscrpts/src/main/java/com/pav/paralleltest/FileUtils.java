package com.pav.paralleltest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.pav.parallel.testdata.FinancialTransaction;
import com.pav.parallel.testdata.HPXInputXML;

public class FileUtils 
{

	public HPXInputXML unmarshallXML(StringBuilder xmlData) throws JAXBException

	{
		JAXBContext jaxbContext;
		jaxbContext = JAXBContext.newInstance(HPXInputXML.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		HPXInputXML objXML;
		objXML = (HPXInputXML) jaxbUnmarshaller.unmarshal(new StringReader(xmlData.toString()));
		return objXML;

	}

	public FinancialTransaction unmarshallFTXML(StringBuilder xmlData) throws JAXBException

	{
		JAXBContext jaxbContext;
		jaxbContext = JAXBContext.newInstance(FinancialTransaction.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		FinancialTransaction objXML;
		objXML = (FinancialTransaction) jaxbUnmarshaller.unmarshal(new StringReader(xmlData.toString()));
		return objXML;

	}
	@SuppressWarnings("resource")
	public StringBuilder readFileToString(String fileName) throws IOException {
		BufferedReader br;
		br = new BufferedReader(new FileReader(new File(fileName)));
		String line;
		StringBuilder data;
		data = new StringBuilder();
		while ((line = br.readLine()) != null) {
			data.append(line.trim());
		}
		return data;
	}

	ArrayList<String> getFilesFromDir(String expDirName) {
		ArrayList<String> fileNames = new ArrayList<String>();
		File dir = new File(expDirName);
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isFile() && file.getName().endsWith("xml")) {
				fileNames.add(file.getName());
			}
		}
		return fileNames;
	}

ArrayList<String> getTxtFilesFromDir(String expDirName) {
	ArrayList<String> fileNames = new ArrayList<String>();
	File dir = new File(expDirName);
	File[] files = dir.listFiles();
	for (File file : files) {
		if (file.isFile() && (file.getName().endsWith("TXT") || file.getName().endsWith("txt"))) {
			fileNames.add(file.getName());
		}
	}
	return fileNames;
}
}
package testProj.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import testProj.test.Data.FinancialTransaction;
import testProj.test.Data.HPXInputXML;


public class App {
	String baseProjectPath = System.getProperty("user.dir");

	ExtentReports extent;
	ExtentTest logger;
	// ExtentHtmlReporter htmlReporter;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");
	Logger LOG = LoggerFactory.getLogger(App.class);
	
	@BeforeTest
	public void setUpReport() {
		// htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +
		// "/test-output/report.html");
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/report.html");
		// extent.setSystemInfo("Host Name", "Test");
		// extent.setSystemInfo("Environment", "XML Validation");
		// extent.setSystemInfo("User Name", "Test");
		extent.addSystemInfo("Host Name", "Test").addSystemInfo("Environment", "XML Validation")
				.addSystemInfo("User Name", "Test");
		extent.loadConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
		// htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir") +
		// "/extent-config.xml"));
		// extent.attachReporter(htmlReporter);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = System.getProperty("user.dir") + "/test-output/" + logfilename;
		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}
		// logger=extent.createTest("dsdsds");
		// logger = extent.createTest("sadasdasda");
	}

	// String org, String plancode, String type, String expFolder, String actFolder
	@Test
	public void xmlTest() throws Exception { // (String org, String plancode, String type, String expFolder, String
												// actFolder) throws Exception {
		PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/config.property"));
		System.out.println("Property is: " + props.getProperty("FinanceCheckRecordArrayElements"));
		ArrayList<String> orgNames = getOrgNames();
		for (String orgName : orgNames) {
			ArrayList<String> planCodes = getPlanCodesForOrg(orgName);
			for (String planCode : planCodes) {
				ArrayList<String> payTypes = getPayTypes(orgName);
				for (String payType : payTypes) 
				{
					String expDirName = "/Users/Shared/paymentfilesvalidation/" + orgName + "/" + planCode + "/Expected/" + payType;
					String actDirName = "/Users/Shared/paymentfilesvalidation/" + orgName + "/" + planCode + "/Actual/" + payType;
					System.out.println(expDirName);

					ArrayList<String> expFileNames = getFilesFromDir(expDirName);
					ArrayList<String> actFileNames = getFilesFromDir(actDirName);

					if (expFileNames.size() != 1 || actFileNames.size() != 1) {
						logger = extent.startTest(expDirName);
						System.out.println("ERROR !! - Either expected or Actual have either more than 1 or 0 files.");
						logger.log(LogStatus.FAIL, "Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("DDDDDD "+logger.getRunStatus());

					} 
					else 
					{
						try
						{
							String expectedOnlyfilename = expFileNames.get(0);
							String actualOnlyfilename = actFileNames.get(0);
							String expectedfilename = expDirName + "/" + expectedOnlyfilename;
							String actualfilename = actDirName + "/" + actualOnlyfilename;
							LOG.info("Expected File -- " + expectedfilename);
							LOG.info("Actual File -- " + actualfilename);
							// Convert all values that has to be validated to key value pair for iteration
							
	
							StringBuilder sbExpected = readFileToString(expectedfilename);
							StringBuilder sbActual = readFileToString(actualfilename);
	
							switch(orgName)
							{
								case "carefirst":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateCarefirst(expectedOnlyfilename,sbExpected,sbActual);
									break;
								case "bcbsnc":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual);
									break;
								case "premera":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual);
									break;
								case "wellmark":
									logger = extent.startTest(orgName +" - "+expectedOnlyfilename);
									validateNonCarefirst(expectedOnlyfilename,sbExpected,sbActual);
									break;
							}									
						}
						catch(Exception e)
						{
							logger.log(LogStatus.ERROR, "Error parsing xml");
						}
					}
					
					if(logger.getRunStatus().toString().equalsIgnoreCase("skip") || 
							logger.getRunStatus().toString().equalsIgnoreCase("fail") ||
							logger.getRunStatus().toString().equalsIgnoreCase("error"))
					{
						
					}
					else 
					{
						logger.log(LogStatus.PASS, "All elements passed");
					}
				}

			}
		}
	}

	private void validateNonCarefirst(String expectedOnlyfilename, StringBuilder sbExpected, StringBuilder sbActual) 
	{
		try 
		{

			FinancialTransaction objExpected = unmarshallFTXML(sbExpected);
			FinancialTransaction objActual = unmarshallFTXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = getKeyValueForFields();
			if (objActual.getDetail().size() != objExpected.getDetail().size()) {
				logger.log(LogStatus.FAIL,
						"Count of Detail do not match. Expected -" + objExpected.getDetail().size()
								+ " Actual - " + objActual.getDetail().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getDetail().size()
						+ " Actual - " + objActual.getDetail().size());
				
			}
			for (int expCtr = 0; expCtr < objExpected.getDetail().size(); expCtr++) {
				String expPayIdNo = objExpected.getDetail().get(expCtr).getFinanceCheckRecordArray()
						.getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(LogStatus.SKIP, "Empty Payee No detected");
					
					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;

					for (int actCtr = 0; actCtr < objActual.getDetail().size(); actCtr++) {
						String actPayIdNo = objActual.getDetail().get(actCtr)
								.getFinanceCheckRecordArray().getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println(
									"Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);
								for (String field : fieldsToValidate) 
								{
									AssertionUtilOthers utilObj = new AssertionUtilOthers(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr,
											actCtr, field);
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(LogStatus.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}
					
					
				}

			}

			LOG.info("DDDDDD "+logger.getRunStatus());
			
		} catch (JAXBException e) {
			logger.log(LogStatus.ERROR, "Error Parsing file");
			e.printStackTrace();
		}
		
	}

	private void validateCarefirst(String expectedOnlyfilename,StringBuilder sbExpected,StringBuilder sbActual) 
	{
		try {

			HPXInputXML objExpected = unmarshallXML(sbExpected);
			HPXInputXML objActual = unmarshallXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = getKeyValueForFields();
			
			if (objActual.getMailset().size() != objExpected.getMailset().size()) {
				logger.log(LogStatus.FAIL,
						"Count of mailset do not match. Expected -" + objExpected.getMailset().size()
								+ " Actual - " + objActual.getMailset().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getMailset().size()
						+ " Actual - " + objActual.getMailset().size());
				
			}
			for (int expCtr = 0; expCtr < objExpected.getMailset().size(); expCtr++) {
				String expPayIdNo = objExpected.getMailset().get(expCtr).getFinanceCheckRecordArray()
						.getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(LogStatus.SKIP, "Empty Payee No detected");
					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;

					for (int actCtr = 0; actCtr < objActual.getMailset().size(); actCtr++) {
						String actPayIdNo = objActual.getMailset().get(actCtr)
								.getFinanceCheckRecordArray().getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println(
									"Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);
								for (String field : fieldsToValidate) {
									AssertionUtilCarefirst utilObj = new AssertionUtilCarefirst(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr,
											actCtr, field);
									// utilObj.assertValues(objExpected, objActual, expCtr, actCtr,
									// field).putAll(results);;
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(LogStatus.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}
					

				}

			}

		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
	}

	public HPXInputXML unmarshallXML(StringBuilder xmlData) throws JAXBException

	{
		JAXBContext jaxbContext;
		jaxbContext = JAXBContext.newInstance(HPXInputXML.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		HPXInputXML objXML;
		objXML = (HPXInputXML) jaxbUnmarshaller.unmarshal(new StringReader(xmlData.toString()));
		return objXML;

	}

	public FinancialTransaction unmarshallFTXML(StringBuilder xmlData) throws JAXBException

	{
		JAXBContext jaxbContext;
		jaxbContext = JAXBContext.newInstance(FinancialTransaction.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		FinancialTransaction objXML;
		objXML = (FinancialTransaction) jaxbUnmarshaller.unmarshal(new StringReader(xmlData.toString()));
		return objXML;

	}
	@SuppressWarnings("resource")
	public StringBuilder readFileToString(String fileName) throws IOException {
		BufferedReader br;
		br = new BufferedReader(new FileReader(new File(fileName)));
		String line;
		StringBuilder data;
		data = new StringBuilder();
		while ((line = br.readLine()) != null) {
			data.append(line.trim());
		}
		return data;
	}

	private ArrayList<String> getFilesFromDir(String expDirName) {
		ArrayList<String> fileNames = new ArrayList<String>();
		File dir = new File(expDirName);
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isFile() && file.getName().endsWith("xml")) {
				fileNames.add(file.getName());
			}
		}
		return fileNames;
	}

	private ArrayList<String> getPayTypes(String orgName) {
		ArrayList<String> payTypes = new ArrayList<String>();
		switch (orgName) {
		case "carefirst":
			List<String> cfList = Arrays.asList("CHK","EFT");
			payTypes.addAll(cfList);
			break;
		case "bcbsnc":
			List<String> bsbList = Arrays.asList("CHK", "EFT", "NON", "NONSUB", "SUBCHK");
			payTypes.addAll(bsbList);
			break;
		case "premera":
			List<String> pList = Arrays.asList("CHK");//,"EFT");
			payTypes.addAll(pList);
			break;
		case "wellmark":
			List<String> wList = Arrays.asList("CHK","EFT");
			payTypes.addAll(wList);
			break;
			
		}
		return payTypes;

	}

	private ArrayList<String> getPlanCodesForOrg(String orgName) {
		ArrayList<String> planCodes = new ArrayList<String>();
		if (orgName.equalsIgnoreCase("carefirst")) {
			planCodes.add("080"); // "08"580","581"};
			planCodes.add("580");
			planCodes.add("581");
		} 
		else if (orgName.equalsIgnoreCase("bcbsnc")) 
		{
			planCodes.add("810");
		}
		else if (orgName.equalsIgnoreCase("premera")) 
		{
			planCodes.add("430");
		}
		else if (orgName.equalsIgnoreCase("wellmark")) 
		{
			planCodes.add("140");
		}
		return planCodes;
	}

	private ArrayList<String> getOrgNames() {
		ArrayList<String> orgNames = new ArrayList<String>();
		//orgNames.add("carefirst");
		orgNames.add("bcbsnc");
		//orgNames.add("premera");
		//orgNames.add("wellmark");
		return orgNames;
	}

	private HashMap<String, String[]> getKeyValueForFields() {
		HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
		String[] fieldsToValidateForFCRArray = { "PayeeName", "CheckAmount", "VoucherCode", "StateCode", "FEPSPLIT1HO",
				"FEPSPLIT2SO", "FEPSPLIT3BO", "FEPSPLIT4HMO", "FEPSPLIT5SS", "FEPSPLIT6BF", "PayeeAddress1",
				"PayeeAddress2", "PayeeAddress3", "PayeeCity", "PayeeState", "PayeeZip", "PayeeAlternateID",
				"MBRNumber", "PayeeType", "PaymentType", "TaxId", "PlanCode" };
		String[] fieldsToValidateForSPRElements = { "OutputFormat", "Application", "HPXPrintInd", "MedicalOrDental" };
		String[] fieldsToValidateForNOPRD = { "MailingAddFirstName", "ChkMailingAddLine1", "ChkMailingAddCity",
				"ChkMailingAddState", "ChkMailingAddZip", "CheckAmountSummary" };
		String[] fieldsToValidateForPaymentElements = { "ProviderNumber", "ProviderTaxID", "ProviderNPINumber",
				"PayeeNumber" };
		String[] fieldsToValidateForRemarkElements = { "RemarkCode", "RemarkDescription", "ClaimNumber" };
		
		String[] fieldsToValidateForClaimElements = {"ClaimNumber" };
		keyValueForFields.put("FCRArray", fieldsToValidateForFCRArray);
		keyValueForFields.put("SPREElements", fieldsToValidateForSPRElements);
		keyValueForFields.put("NOPRD", fieldsToValidateForNOPRD);
		keyValueForFields.put("PaymentElements", fieldsToValidateForPaymentElements);
		keyValueForFields.put("RemarkElements", fieldsToValidateForRemarkElements);
		keyValueForFields.put("ClaimArrayElements", fieldsToValidateForClaimElements);
		return keyValueForFields;
	}

	@AfterTest
	public void endReport() {
		// extent.endTest(logger);
		extent.flush();
		// extent.close();
	}

}
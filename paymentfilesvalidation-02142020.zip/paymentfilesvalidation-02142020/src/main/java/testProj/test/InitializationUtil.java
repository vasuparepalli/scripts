package testProj.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class InitializationUtil 
{


	ArrayList<String> getPayTypes(String orgName) {
		ArrayList<String> payTypes = new ArrayList<String>();
		switch (orgName) {
		case "carefirst":
			List<String> cfList = Arrays.asList("CHK","EFT");
			payTypes.addAll(cfList);
			break;
		case "bcbsnc":
			List<String> bsbList = Arrays.asList("CHK", "EFT", "SUBCHK");
			payTypes.addAll(bsbList);
			break;
		case "premera":
			List<String> pList = Arrays.asList("CHK","EFT","SUBCHK");
			payTypes.addAll(pList);
			break;
		case "wellmark":
			List<String> wList = Arrays.asList("CHK","SUBCHK");
			payTypes.addAll(wList);
			break;
			
		}
		return payTypes;

	}

	ArrayList<String> getPlanCodesForOrg(String orgName) {
		ArrayList<String> planCodes = new ArrayList<String>();
		if (orgName.equalsIgnoreCase("carefirst")) {
			planCodes.add("080"); // "08"580","581"};
			planCodes.add("580");
			planCodes.add("581");
		} 
		else if (orgName.equalsIgnoreCase("bcbsnc")) 
		{
			planCodes.add("810");
		}
		else if (orgName.equalsIgnoreCase("premera")) 
		{
			planCodes.add("430");
			planCodes.add("939");
		}
		else if (orgName.equalsIgnoreCase("wellmark")) 
		{
			planCodes.add("140");
		}
		return planCodes;
	}

	ArrayList<String> getOrgNames() {
		ArrayList<String> orgNames = new ArrayList<String>();
		orgNames.add("carefirst");
		orgNames.add("bcbsnc");
		orgNames.add("premera");
		orgNames.add("wellmark");
		return orgNames;
	}

	HashMap<String, String[]> getKeyValueForFields(String payType) {
		HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
		String[] fieldsToValidateForFCRArray = { "PayeeName", "CheckAmount", "VoucherCode", "StateCode", "FEPSPLIT1HO",
				"FEPSPLIT2SO", "FEPSPLIT3BO", "FEPSPLIT4HMO", "FEPSPLIT5SS", "FEPSPLIT6BF", "PayeeAddress1",
				"PayeeAddress2", "PayeeAddress3", "PayeeCity", "PayeeState", "PayeeZip", "PayeeAlternateID",
				"MBRNumber", "PayeeType", "PaymentType", "TaxId", "PlanCode" };
		String[] fieldsToValidateForSPRElements = { "OutputFormat", "Application", "HPXPrintInd", "MedicalOrDental" };
		String[] fieldsToValidateForNOPRD = { "MailingAddFirstName", "ChkMailingAddLine1", "ChkMailingAddCity",
				"ChkMailingAddState", "ChkMailingAddZip", "CheckAmountSummary" };
		String[] fieldsToValidateForPaymentElements = { "ProviderNumber", "ProviderTaxID", "ProviderNPINumber",
				"PayeeNumber" };
		String[] fieldsToValidateForRemarkElements = { "RemarkCode", "RemarkDescription", "ClaimNumber" };
		
		String[] fieldsToValidateForClaimElements = {"ClaimNumber" };
		keyValueForFields.put("FCRArray", fieldsToValidateForFCRArray);
		
		if(!payType.equalsIgnoreCase("SUBCHK"))
		{
			keyValueForFields.put("SPREElements", fieldsToValidateForSPRElements);
			keyValueForFields.put("NOPRD", fieldsToValidateForNOPRD);
			keyValueForFields.put("PaymentElements", fieldsToValidateForPaymentElements);
			keyValueForFields.put("RemarkElements", fieldsToValidateForRemarkElements);
			keyValueForFields.put("ClaimArrayElements", fieldsToValidateForClaimElements);
		}
		return keyValueForFields;
	}
}

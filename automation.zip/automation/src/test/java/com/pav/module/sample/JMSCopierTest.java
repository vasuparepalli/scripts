/*
 * package com.pav.module.sample;
 * 
 * 
 * import static org.junit.Assert.*;
 * 
 * import org.junit.Test;
 * 
 * public class JMSCopierTest {
 * 
 * @Test public void testSendLocalFilesToJMSQueue() { JMSCopier copier = new
 * JMSCopier();
 * 
 * String filePath = ""; String queueName = "copierQueue";
 * 
 * try { copier.sendFileToJMS(filePath, queueName); } catch (Exception e) {
 * fail(e.getMessage()); } }
 * 
 * }
 */
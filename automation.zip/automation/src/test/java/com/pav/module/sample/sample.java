package com.pav.module.sample;

import org.testng.annotations.Test;

public class sample {
	@Test
	public void sampletest() {
		System.out.println("Test package..");
		String orgs = System.getProperty("OrgName");
		String plan = System.getProperty("PlanName");
		System.out.println("Under execution Organization is: " + orgs + "and Plan Name is: " + plan);
	}
}
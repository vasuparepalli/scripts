package com.pav.edi.datavalidation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileUtils {

	public static String getSegment(String lineStr) {
		if(-1 == lineStr.indexOf('*')) {
			return "";
		}
		return lineStr.substring(0, lineStr.indexOf('*'));
	}

	public static String getSegmentAndIdentifier(String lineStr) {
		return getSegment(lineStr)+"*"+getSegmentIdentifier(lineStr);
	}

	// SegmentIdentifier = Second segment
	public static String getSegmentIdentifier(String lineStr) {
		if(-1 == lineStr.indexOf('*')) {
			return "";
		}
		try{ 
			return lineStr.split("\\*")[1];	
		} catch(Exception e) {
			
		}
		return "";
	}

	
	public static List<String> getListFromFile(File file) throws FileNotFoundException{
	    List<String> resultList = new ArrayList<>();
	    String sCurrentLine;

	    BufferedReader br = new BufferedReader(new FileReader(file));

		try {
			while ((sCurrentLine = br.readLine()) != null) {
				resultList.add(sCurrentLine);
			}
		} catch (IOException e) {
		}
		
		return resultList;
	}

	public static boolean isFileContentSame(File expectedFile, File actualFile) throws FileNotFoundException{
	    String expectedCurrLine;
	    String actualCurrLine;
	    
	    try (BufferedReader expectedBR = new BufferedReader(new FileReader(expectedFile));
	    		BufferedReader actualBR = new BufferedReader(new FileReader(actualFile));) {
			
			while ((expectedCurrLine = expectedBR.readLine()) != null 
					&& (actualCurrLine = actualBR.readLine()) != null) {
				if(!expectedCurrLine.equals(actualCurrLine)) {
					return false;
				}
			}
		} catch (IOException e) {
		}
	    return true;
	}

	public static List<Map<String, String>> findDiffInLine(String expectedLine, String actualLine) {
		List<Map<String, String>> list = new ArrayList<>();
		if(expectedLine.split("\\*").length != actualLine.split("\\*").length) {
			Map<String, String> map = new HashMap<>();
			map.put(expectedLine.substring(expectedLine.indexOf('*'), expectedLine.length()),
					actualLine.substring(actualLine.indexOf('*'), actualLine.length()));
			list.add(map);
			return list;
		
		} else {
			String[] expectedSubsegList = expectedLine.split("\\*"); 
			String[] actualSubsegList = actualLine.split("\\*"); 
			for(int cnt=1; cnt<expectedSubsegList.length; cnt++) {
				if(!expectedSubsegList[cnt].equals(actualSubsegList[cnt])) {
					Map<String, String> map = new HashMap<>();
					map.put(expectedSubsegList[cnt], actualSubsegList[cnt]);
					list.add(map);					
				}
			}
			return list;
		}
		
	}
	
	public static boolean createDirTree(String directoryTreeName) {
		try {
			File dir = new File(directoryTreeName);
			if (!dir.exists()) {
				if (dir.mkdirs()) {
					System.out.println("Successfully created");
				} else {
					System.out.println("Not created");
				}

			} else {
				System.out.println("Directory exists, hence not creating");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return false;
	}

	public static void writeEDICodeToFile(String currFileName, InputStream inputStream, String targetDir) 
			throws IOException {
		
		byte[] buffer = new byte[inputStream.available()];
		inputStream.read(buffer);
	 
		FileUtils.createDirTree(targetDir);
	    File targetFile = new File(targetDir+currFileName);
	    if(!targetFile.exists()) {
	    	targetFile.createNewFile();
	    }
	    OutputStream outStream = new FileOutputStream(targetFile);
	    outStream.write(buffer);
	    outStream.close();
	}

	public static String[] explodeString(String values) {
		if (values.contains(",")) {
			return values.split(",");
		} else {
			return new String[] { values };
		}
	}
	

}

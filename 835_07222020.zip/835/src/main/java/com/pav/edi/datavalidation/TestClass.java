package com.pav.edi.datavalidation;

public class TestClass {

	public static void main(String[] args) {
		String segmentAndIdentifier = "DTA*405*bcehnvk";
		if(!(segmentAndIdentifier.startsWith("BPR*I") 
				|| segmentAndIdentifier.startsWith("TRN*1") 
				|| segmentAndIdentifier.startsWith("DTM*405") 
				|| segmentAndIdentifier.startsWith("SE*") 
				|| segmentAndIdentifier.startsWith("BPR*H"))){
			System.out.println("in");
		} else {			
			System.out.println("out");
		}
	}
}

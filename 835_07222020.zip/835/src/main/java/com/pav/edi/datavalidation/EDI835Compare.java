package com.pav.edi.datavalidation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class EDI835Compare {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EDI835Compare.class);
	final static String CONST_FILENAME = "FileName";
	final static String CONST_SEGMENTNAME = "Segment Name";
	final static String CONST_EXPECTED_LINE = "Expected Line";
	final static String CONST_ACTUAL_LINE = "Actual Line";
	final static String CONST_EXPECTED_VAL = "Expected";
	final static String CONST_ACTUAL_VAL = "Actual";

	public static String HTML = Main.HTML;

	public static void executeFilesComparison(String currOrgName, String currAplancode, File expectedFile, File actualFile, ExtentTest EXTENT_REPORT_LOGGER) {
		
		try {
			if(!executeStep1Comparison(expectedFile, actualFile))
				System.out.println(executeStep2Comparison(expectedFile, actualFile, EXTENT_REPORT_LOGGER,
						currOrgName, currAplancode));
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
//LineByLine Comparision
	private static boolean executeStep1Comparison(File expectedFile, File actualFile) throws FileNotFoundException {
		String logStr = "\n\n"+expectedFile.getName();
		System.out.println(logStr);
		return FileUtils.isFileContentSame(expectedFile, actualFile);
	}
//comparing linebyline and each segment expected and actual value
	public static List<Map<String,String>> executeStep2Comparison(File expectedFile, File actualFile, ExtentTest EXTENT_REPORT_LOGGER,
			String currOrgName, String currAplancode) throws FileNotFoundException {
		List<String> expectedTextList = FileUtils.getListFromFile(expectedFile);
		List<String> actualTextList = FileUtils.getListFromFile(actualFile);
		List<Map<String,String>> resultList = new ArrayList<>();
		
		for(int expCount=0, actCount=0; expCount<expectedTextList.size() && actCount<actualTextList.size(); expCount++) {
//			System.out.println("expCount:"+expCount+"\tactCount"+actCount
//					+"\n\tExp: "+expectedTextList.get(expCount)+"\n\tExp: "+actualTextList.get(actCount));
			
			// If expectedLine = actualLine
			if( expectedTextList.get(expCount).equals(actualTextList.get(actCount)) ) {
				LOGGER.info("Success : Expected Data is: "+expectedTextList.get(expCount));
				LOGGER.info("Success : Actual Data is: "+actualTextList.get(actCount));
				actCount++;

			} else {
				// Error in expected line (segments matching)
				if(FileUtils.getSegment(expectedTextList.get(expCount)).equals(FileUtils.getSegment(actualTextList.get(actCount)))) {

					String segmentAndIdentifier = FileUtils.getSegmentAndIdentifier(expectedTextList.get(expCount));
					if(!(segmentAndIdentifier.startsWith("BPR*I") 
							|| segmentAndIdentifier.startsWith("TRN*1") 
							|| segmentAndIdentifier.startsWith("DTM*405") 
							|| segmentAndIdentifier.startsWith("SE*") 
							|| segmentAndIdentifier.startsWith("BPR*H"))){
						Map<String, String> map = createMapAndLogReport(EXTENT_REPORT_LOGGER, 
								currOrgName, currAplancode, expectedFile.getName(), segmentAndIdentifier,
								expectedTextList.get(expCount), actualTextList.get(actCount), 
								String.valueOf(expCount+1), String.valueOf(actCount+1));
						resultList.add(map);
	
						actCount++;
					}
				}
				
				// Line missing in actual (Alternative #2)
				else {
					List<Integer> missedExpectedLineNos = new ArrayList<>();
					for(int tmpExpCount=expCount+1; tmpExpCount<expectedTextList.size() ; tmpExpCount++) {
						missedExpectedLineNos.add(tmpExpCount-1);
						// Check if next Expected line matches current Actual line 
						if(expectedTextList.get(tmpExpCount).equals(actualTextList.get(actCount))){

							// Log all missed Expected lines in Actual 
							for(int missedExpectedLineNo: missedExpectedLineNos) {
								
								String segmentAndIdentifier = FileUtils.getSegmentAndIdentifier(expectedTextList.get(missedExpectedLineNo));
								if(!(segmentAndIdentifier.startsWith("BPR*I") 
										&& segmentAndIdentifier.startsWith("TRN*1") 
										&& segmentAndIdentifier.startsWith("DTM*405") 
										&& segmentAndIdentifier.startsWith("SE*") 
										&& segmentAndIdentifier.startsWith("BPR*H"))){

									Map<String, String> map = createMapAndLogReport(EXTENT_REPORT_LOGGER, 
											currOrgName, currAplancode, expectedFile.getName(), segmentAndIdentifier,
											segmentAndIdentifier, "Absent", 
											String.valueOf(missedExpectedLineNo+1), null);
									resultList.add(map);
								
//								String logStr = "\nExpected line number:-"+missedExpectedLineNo+"-"+expectedTextList.get(missedExpectedLineNo);
//								logStr = "\nActual line number:-N/A-N/A";
//								System.out.println(logStr);
								}
							}
							expCount = tmpExpCount;
//							continue;
							break;
						}
					}
					actCount++;
				}
				
			}
		}
		return resultList;
	}

	public static Map<String, String> createMapAndLogReport(ExtentTest EXTENT_REPORT_LOGGER, 
			String currOrgName, String currAplancode, String fileName, String segmentName, 
			String expectedVal, String actualVal, String expLineNo, String actLineNo) {
		expectedVal = expectedVal.replace("~", "");
		actualVal = actualVal.replace("~", "");
		
		Map<String, String> map = new HashMap<>();
		map.put(CONST_FILENAME, fileName);
		map.put(CONST_SEGMENTNAME, segmentName);
		map.put("Expected Line", expLineNo);

		if(actLineNo!=null) {
			Map<String,String> subsegMap = FileUtils.findDiffInLine(expectedVal, actualVal).get(0);
			for(Map.Entry subseg: subsegMap.entrySet()) {
				map.put(CONST_EXPECTED_VAL, String.valueOf(subseg.getKey()));
				map.put(CONST_ACTUAL_VAL, String.valueOf(subseg.getValue()));
			}
		}
		StringBuffer logStr = new StringBuffer("\nExpected line number:-").append(expLineNo).append("-").append(expectedVal)
				.append("\nActual line number:-").append(null!=actLineNo?actLineNo:"N/A").append("-").append(actualVal);
		System.out.println(logStr.toString());
		
		LOGGER.info("Failure : Expected Data is: "+expectedVal);
		LOGGER.info("Failure : Actual Data is: "+actualVal);
		
		EXTENT_REPORT_LOGGER.log(Status.FAIL, 
				String.format(HTML, currOrgName, currAplancode, fileName.split(".txt")[0], segmentName, map.get(CONST_EXPECTED_VAL), map.get(CONST_ACTUAL_VAL))); 
		return map;
	}

}
